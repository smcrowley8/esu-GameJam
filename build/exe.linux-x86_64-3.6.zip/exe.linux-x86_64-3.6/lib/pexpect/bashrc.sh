source /etc/bash.bashrc
source ~/.bashrc

# Reset PS1 so pexpect can find it
PS1="$"
